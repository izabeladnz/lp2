package com.example.alunos.medtime;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void abrirTelaRemedio(View v){

        Intent it = new Intent(this, RemedioActivity.class);
        startActivity(it);
    }

    public void abrirTelaAdd(View v){

        Intent it = new Intent(this, AddActivity.class);
        startActivity(it);
    }

    public void abrirTelaSobre(View v){

        Intent it = new Intent(this, SobreActivity.class);
        startActivity(it);
    }
}