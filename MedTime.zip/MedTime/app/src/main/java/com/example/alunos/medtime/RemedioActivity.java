package com.example.alunos.medtime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RemedioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remedio);
    }
}
